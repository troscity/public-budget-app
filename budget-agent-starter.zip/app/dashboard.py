import os
import duckdb
import pandas as pd
import streamlit as st

DB_PATH = os.path.join(os.path.dirname(os.path.dirname(__file__)), "db", "ledger.duckdb")

@st.cache_data
def load_df():
    con = duckdb.connect(DB_PATH, read_only=True)
    df = con.execute("SELECT * FROM transactions").fetchdf()
    df["posted_at"] = pd.to_datetime(df["posted_at"])
    return df

st.title("Budget Agent — Dashboard")
df = load_df()
if df.empty:
    st.info("No data yet. Ingest some CSVs then refresh.")
else:
    # Filters
    months = sorted(df["posted_at"].dt.to_period("M").astype(str).unique())
    month = st.selectbox("Month", months, index=len(months)-1)
    sel = df[df["posted_at"].dt.to_period("M").astype(str) == month]

    st.metric("Income", f"${sel[sel.amount>0]['amount'].sum():,.2f}")
    st.metric("Expenses", f"${sel[sel.amount<0]['amount'].sum():,.2f}")
    st.metric("Net", f"${sel['amount'].sum():,.2f}")

    st.subheader("By Category")
    st.dataframe(sel.groupby("category", dropna=False)["amount"].sum().sort_values().to_frame("total").reset_index())

    st.subheader("Transactions")
    st.dataframe(sel.sort_values("posted_at", ascending=False))
